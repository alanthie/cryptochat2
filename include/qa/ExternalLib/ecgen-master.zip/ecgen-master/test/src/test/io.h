
#ifndef ECGEN_IO_H
#define ECGEN_IO_H

#include "default.h"
#include "input.h"
#include "output.h"

void io_setup();

void io_teardown();

#endif  // ECGEN_IO_H

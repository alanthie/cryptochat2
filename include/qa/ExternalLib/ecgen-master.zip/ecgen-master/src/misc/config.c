/*
 * ecgen, tool for generating Elliptic curve domain parameters
 * Copyright (C) 2017-2018 J08nY
 */
#include "config.h"

config_t cfg_s;
config_t *cfg = &cfg_s;
# ecgen docs

 - [Output](output.md)
 - [Points](points.md)

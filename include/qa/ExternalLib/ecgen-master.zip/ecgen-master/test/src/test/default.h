/*
 * ecgen, tool for generating Elliptic curve domain parameters
 * Copyright (C) 2017-2018 J08nY
 */
#ifndef ECGEN_TEST_DEFAULT_H
#define ECGEN_TEST_DEFAULT_H

void default_setup(void);

void default_teardown(void);

#endif  // ECGEN_UTILS_H
